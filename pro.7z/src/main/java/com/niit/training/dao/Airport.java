package com.niit.training.dao;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="airport")
public class Airport implements Serializable {
	
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

@Id
@Column(name = "code")
private String code;

@Column(name = "name", nullable = false)
private String name;

@Column(name = "city", nullable = false)
private String city;

public String getCode() {
	return code;
}
public void setCode(String code) {
	this.code = code;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}

}

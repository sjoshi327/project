package com.niit.training.services;

public class LoginService {
	public boolean validateUser(String user, String password) {
		return user.equalsIgnoreCase("training") 
				&& password.equals("niit@123");
	}

}
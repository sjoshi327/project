package com.niit.training.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.niit.training.services.LoginService;

@Controller
public class LoginController {

	@RequestMapping(value="/Login.do",method=RequestMethod.POST)	
	@ResponseBody
	public String doLogin(@RequestParam String name, @RequestParam String password) {
		LoginService service = new LoginService();
		if (service.validateUser(name, password))
			return "Welcome " +name;
		else {
			return "Invalid credentials";
		}
	}
}
